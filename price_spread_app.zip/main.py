
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.clock import Clock
from threading import Thread
import asyncio
import websockets
import json

COINS = ["ETH", "BNB", "ADA", "SOL", "XRP", "DOT", "LINK", "MATIC", "AVAX", "ATOM", "ALGO", "XLM", "VET", "XTZ", "HBAR", "FTM", "EGLD", "NEAR", "ARB", "OP"]
PAIRS = [f"{coin}USDT" for coin in COINS]

class SpreadApp(App):
    def build(self):
        self.layout = BoxLayout(orientation='vertical')
        self.labels = {}
        for pair in PAIRS:
            lbl = Label(text=f"{pair}: loading...")
            self.labels[pair] = lbl
            self.layout.add_widget(lbl)
        Clock.schedule_interval(lambda dt: self.sort_labels(), 3)
        Thread(target=self.run_websockets).start()
        return self.layout

    def sort_labels(self):
        sorted_pairs = sorted(self.labels.items(), key=lambda x: float(x[1].text.split()[-1].replace('%','')) if '%' in x[1].text else 0, reverse=True)
        self.layout.clear_widgets()
        for pair, lbl in sorted_pairs:
            self.layout.add_widget(lbl)

    def update_label(self, pair, bybit_price, okx_price):
        if bybit_price and okx_price:
            spread = ((bybit_price - okx_price) / okx_price) * 100
            text = f"{pair}: Bybit={bybit_price:.2f}, OKX={okx_price:.2f}, Spread={spread:+.2f}%"
            self.labels[pair].text = text

    async def fetch_prices(self):
        bybit_uri = "wss://stream.bybit.com/v5/public/linear"
        okx_uri = "wss://ws.okx.com:8443/ws/v5/public"

        async with websockets.connect(bybit_uri) as bybit_ws, websockets.connect(okx_uri) as okx_ws:
            await bybit_ws.send(json.dumps({"op": "subscribe", "args": [{"channel": "tickers", "instId": f"{pair}" } for pair in PAIRS]}))
            await okx_ws.send(json.dumps({"op": "subscribe", "args": [{"channel": "tickers", "instId": f"{pair}" } for pair in PAIRS]}))

            bybit_data = {}
            okx_data = {}

            while True:
                done, _ = await asyncio.wait(
                    [bybit_ws.recv(), okx_ws.recv()],
                    return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    msg = json.loads(task.result())
                    if 'data' in msg:
                        data = msg['data']
                        if isinstance(data, list):
                            data = data[0]
                        symbol = data.get("instId", "")
                        last_price = float(data.get("lastPrice") or data.get("last", 0))
                        if "bybit" in str(task):
                            bybit_data[symbol] = last_price
                        else:
                            okx_data[symbol] = last_price
                        if symbol in bybit_data and symbol in okx_data:
                            self.update_label(symbol, bybit_data[symbol], okx_data[symbol])

    def run_websockets(self):
        asyncio.run(self.fetch_prices())

if __name__ == "__main__":
    SpreadApp().run()
